<br>
<h2><?= $title; ?></h2>
<p>Welcome to the MyBlog Application</p>