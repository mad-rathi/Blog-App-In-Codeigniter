<br>
<h2><?= $title ?></h2>

<?= validation_errors(); ?>
<?= form_open_multipart('users/register'); ?>
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" name="name" id="name" placeholder="Name" class="form-control">
    </div>
    <div class="form-group">
        <label for="zipcode">Zipcode</label>
        <input type="text" name="zipcode" id="zipcode" placeholder="Zipcode" class="form-control">
    </div>
    <div class="form-group">
        <label for="username">Username</label>
        <input type="text" name="username" id="username" placeholder="Username" class="form-control">
    </div>
    <div class="form-group">
        <label for="email">Email</label>
        <input type="email" name="email" id="email" placeholder="Email" class="form-control">
    </div>
    <div class="form-group">
        <label for="password">Password</label>
        <input type="password" name="password" id="password" placeholder="Password" class="form-control">
    </div>
    <div class="form-group">
        <label for="password2">Confirm Password</label>
        <input type="password" name="password2" id="password2" placeholder="Confirm Password" class="form-control">
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>