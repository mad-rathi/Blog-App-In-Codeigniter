<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/font-awesome.min.css'); ?>">
    <script src="https://cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
    <script src="<?= base_url('assets/js/bootstrap.min.js'); ?>"></script>
    <script src="<?= base_url('assets/js/jquery-3.5.1.min.js'); ?>"></script>
    <title><?= $title . ' Archives'; ?> - MyBlog</title>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary p-0">
        <div class="container">
            <ul class="navbar-nav navbar-right">
                <!-- <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('users/register'); ?>">Register</a>
                </li> -->
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('posts/create'); ?>">Create Post</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('categories/create'); ?>">Create Category</a>
                </li>
            </ul>
        </div>
    </nav>

    <nav class="navbar navbar-expand-lg navbar-dark bg-secondary p-4">
        <div class="container">
            <a class="navbar-brand" href="<?= base_url(); ?>">MyBlog</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
    </nav>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary p-1">
        <div class="container">
            <div class="collapse navbar-collapse" id="navbarColor01">
            <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="<?= base_url(); ?>"><i class="fa fa-home fa-2x"></i></a>
                    </li>
                    <?php foreach($categories as $category) { ?>
                        <li class="nav-item"><a class="nav-link" href="<?= site_url('categories/'.strtolower($category['name'])); ?>"><?= strtoupper($category['name']); ?></a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php 
            if($this->session->flashdata('user_registered')) :
                echo '<p class="alert alert-dismissible alert-success">' . $this->session->flashdata('user_registered') . '</p>';
            endif;
        ?>
        <?php 
            if($this->session->flashdata('post_created')) :
                echo '<div class="alert alert-dismissible alert-success">' . $this->session->flashdata('post_created') . '</div>';
            endif; 
        ?>
        <?php 
            if($this->session->flashdata('post_deleted')) :
                echo '<div class="alert alert-dismissible alert-success">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <p>' . $this->session->flashdata('post_deleted') . '</p></div>';
            endif; 
        ?>
        <?php 
            if($this->session->flashdata('post_updated')) :
                echo '<p class="alert alert-dismissible alert-success">' . $this->session->flashdata('post_updated') . '</p>';
            endif; 
        ?>
        <?php 
            if($this->session->flashdata('category_created')) :
                echo '<p class="alert alert-dismissible alert-success">' . $this->session->flashdata('category_created') . '</p>';
            endif; 
        ?>
        <?php 
            if($this->session->flashdata('comment_created')) :
                echo '<p class="alert alert-dismissible alert-success">' . $this->session->flashdata('comment_created') . '</p>';
            endif; 
        ?>