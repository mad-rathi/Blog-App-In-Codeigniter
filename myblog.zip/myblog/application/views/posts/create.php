<br>
<h2><?= $title; ?></h2>
<?= validation_errors(); ?>
<?= form_open_multipart('posts/create'); ?>
    <div class="form-group">
        <label for="title">Title</label>
        <input type="text" class="form-control" id="title" name="title" placeholder="Add Title...">
    </div>
    <div class="form-group">
        <label for="body">Body</label>
        <textarea type="text" class="form-control" id="editor1" name="body" placeholder="Add Body..."></textarea>
    </div>
    <div class="form-group">
        <label for="categories">Category</label>
        <select name="category_id" class="form-control">
            <?php foreach($categories as $category) { ?>
                <option value="<?= $category['id'] ?>"><?= $category['name'] ?></option>
            <?php } ?>
        </select>
    </div>
    <div class="form-group">
        <label for="uploadImage">Add Placeholder Image</label>
        <input type="file" name="userfile" id="uploadImage" size="20" class="form-control">
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>