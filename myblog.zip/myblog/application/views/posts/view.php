<br>
<h3><?= $post['title']; ?></h3>
<small class="post-date"><i class="fa fa-calendar"></i>&ensp;<?= date("F d, Y", strtotime($post['created_at'])); ?></small><br>
<img src="<?= site_url(); ?>assets/images/posts/<?= $post['post_image']; ?>"><br><br>
<div class="post-body">
    <?= $post['body']; ?>
</div>

<br><hr>

<?= form_open('/posts/delete/' . $post['id']); ?>
    <a class="btn btn-secondary pull-left" href="<?= base_url(); ?>posts/edit/<?= $post['slug']; ?>">Edit</a>&ensp;
    <input type="submit" value="Delete" class="btn btn-danger">
</form>

<br><hr>

<h4>Comments</h4>
<?php if($comments) : ?>
    <?php foreach($comments as $comment) { ?>
        <div class="card bg-light mb-2">
            <div class="card-body p-2 pt-3">
                <h6>[<strong><?= $comment['name'] ?></strong>] <?= $comment['body'] ?></h6>
            </div>
        </div>
    <?php } ?>
<?php else : ?>
    <p>No Comments to display</p>
<?php endif; ?>

<br><hr>

<h4>Add Comment</h4>
<?= validation_errors(); ?>
<?= form_open('/comments/create/' . $post['id']); ?>
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" name="name" id="name" class="form-control">
    </div>
    <div class="form-group">
        <label for="email">Email</label>
        <input type="text" name="email" id="email" class="form-control">
    </div>
    <div class="form-group">
        <label for="body">Body</label>
        <textarea name="body" id="body" class="form-control"></textarea>
    </div>
    <input type="hidden" name="slug" value="<?= $post['slug']; ?>">
    <button class="btn btn-primary" type="submit">Submit</button>
</form>