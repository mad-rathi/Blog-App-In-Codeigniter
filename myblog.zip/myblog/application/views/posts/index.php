<br>
<h2><?= $title; ?></h2>
<?php foreach($posts as $post) : ?>
    <br>
    <h4><?= $post['title']; ?></h4>
    <div class="row">
        <div class="col-md-3">
            <img class="post-thumb" src="<?= site_url(); ?>assets/images/posts/<?= $post['post_image'] ?>">
        </div>
        <div class="col-md-9">
            <small class="post-date"><i class="fa fa-calendar"></i>&ensp;<?= date("F d, Y", strtotime($post['created_at'])); ?></small><br>
            <?= word_limiter($post['body'], 35); ?>
            <br><br>
            <p><a class="btn btn-primary" href="<?= site_url('/posts/' . $post['slug']) ?>">Read More</a></p>
        </div>
    </div>
    <hr>
<?php endforeach; ?>