<div class="container main-content">
    <div class="content">
        <div class="topbar">
            <h2>Welcome To The SkinID<sup>TM</sup> Questionnaire.</h2>
        </div>
        <div class="survey-element">
            <div class="quest-head">
                <h3>Skin Care</h3>
            </div>
            <div class="question">
                <h4>Please Select Your Concerns: </h4>
            </div>
            <div class="choices">
                <!--<div class="check-choices">
                    <h6>
                        Choice1
                        <label class="switch">
                            <input type="checkbox" name="choices" value="choices1" id="choices1">
                            <span class="slider round"></span>
                        </label>
                    </h6>
                    <h6>
                        Choice1
                        <label class="switch">
                            <input type="checkbox" name="choices" value="choices1" id="choices1">
                            <span class="slider round"></span>
                        </label>
                    </h6>
                    <h6>
                        Choice1
                        <label class="switch">
                            <input type="checkbox" name="choices" value="choices1" id="choices1">
                            <span class="slider round"></span>
                        </label>
                    </h6>
                    <h6>
                        Choice1
                        <label class="switch">
                            <input type="checkbox" name="choices" value="choices1" id="choices1">
                            <span class="slider round"></span>
                        </label>
                    </h6>                    
                </div> -->
                <div class="radio-choices">
                    <input type="radio" name="choices" value="choices1" id="choices1">
                    <label for="choices1">
                        Choice1
                    </label>
                    &emsp;&emsp;&emsp;
                    <input type="radio" name="choices" value="choices2" id="choices2">
                    <label for="choices2">
                        Choice2
                    </label>
                    <br>
                    <input type="radio" name="choices" value="choices3" id="choices3">
                    <label for="choices3">
                        Choice3
                    </label>
                    &emsp;&emsp;&emsp;
                    <input type="radio" name="choices" value="choices4" id="choices4">
                    <label for="choices4">
                        Choice4
                    </label>
                </div>
            </div>
            <div class="btns">
                <button type="button" class="btn btn-primary" id="prev">Prev</button>
                <button type="button" class="btn btn-primary" id="next">Next</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#prev').click(function() {
            $.ajax({
                url: '',
                type: 'post',
                data: {
                    
                },
                success: function(response) {
                    
                }
            });
        });

        $('#next').click(function() {
            $.ajax({
                url: '',
                type: 'post',
                data: {
                    
                },
                success: function(response) {
                    
                }
            });
        });
    });
</script>